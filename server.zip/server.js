const express = require('express');
const bodyParser = require('body-parser');
const { CognitoUserPool, CognitoUser, AuthenticationDetails } = require('amazon-cognito-identity-js');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());

const poolData = {
    UserPoolId: "ap-southeast-2_kcxg532Ms",
    ClientId: "7j0e6cppu4tcap9kv6uu0u3tls"
};

const userPool = new CognitoUserPool(poolData);

// Sign up endpoint
app.post('/signup', async (req, res) => {
    const { email, password } = req.body;

    try {
        const result = await new Promise((resolve, reject) => {
            userPool.signUp(email, password, [], null, (err, result) => {
                if (err) reject(err);
                else resolve(result);
            });
        });

        console.log('User registered successfully:', result.user.getUsername());
        res.status(200).json({ message: 'User registered successfully', username: result.user.getUsername() });
    } catch (error) {
        console.error('Error during sign up:', error);
        res.status(500).json({ error: error.message || 'Sign up failed' });
    }
});

// Confirm registration endpoint
app.post('/confirm', async (req, res) => {
    const { email, confirmationCode } = req.body;

    const userData = {
        Username: email,
        Pool: userPool
    };

    const cognitoUser = new CognitoUser(userData);

    try {
        const result = await new Promise((resolve, reject) => {
            cognitoUser.confirmRegistration(confirmationCode, true, (err, result) => {
                if (err) reject(err);
                else resolve(result);
            });
        });

        console.log('User confirmed successfully');
        res.status(200).json({ message: 'User confirmed successfully' });
    } catch (error) {
        console.error('Error confirming registration:', error);
        res.status(500).json({ error: error.message || 'Confirmation failed' });
    }
});

// Login endpoint
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    const user = new CognitoUser({
        Username: email,
        Pool: userPool
    });

    const authDetails = new AuthenticationDetails({
        Username: email,
        Password: password
    });

    const authenticateUser = () => {
        return new Promise((resolve, reject) => {
            user.authenticateUser(authDetails, {
                onSuccess: (data) => {
                    console.log("onSuccess:", data);
                    resolve({ success: true, message: "Login successful" });
                },
                onFailure: (err) => {
                    console.error("onFailure:", err);
                    reject({ success: false, message: "Login failed" });
                },
                newPasswordRequired: (data) => {
                    console.log("newPasswordRequired:", data);
                    reject({ success: false, message: "New password required" });
                }
            });
        });
    };

    try {
        const loginResult = await authenticateUser();
        res.status(200).json(loginResult);
    } catch (error) {
        res.status(401).json(error);
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
